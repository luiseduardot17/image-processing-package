# image_processing_devluiseduardo

Description. 
The package image_processing_devluiseduardo is used to:
	- Histogram matching
	- Structural similarity
	- Resize image
Utils:
	- Read image
	- Save image
	- Plot image
	- Plot result
	- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_devluiseduardo

```bash
pip install image_processing_devluiseduardo
```

## Author
Luis Eduardo

## License
[MIT](https://choosealicense.com/licenses/mit/)